
Ghost GOS TV — PWA Package
-------------------------

Files included:
- index.html
- manifest.webmanifest
- service-worker.js
- assets/icons/*.svg and icon PNGs

How to test locally:
1) Serve the folder with a local static server (HTTP) and use ngrok to get HTTPS:
   - Install http-server: npm i -g http-server
   - Run: http-server -p 8080
   - (optional) ngrok http 8080 -> copy the https URL

2) Open the https URL on your Android device and install the PWA from the browser menu,
   or use the install prompt inside the app.

PWA -> APK:
- Use Bubblewrap (Trusted Web Activity) to create an APK:
  npm install -g @bubblewrap/cli
  bubblewrap init --manifest <https://your-ngrok-url/manifest.webmanifest>
  bubblewrap build

Notes:
- Some sites (YouTube, Netflix) block embedding in iframes. If an app doesn't load inside the window, open it in a new tab.
- This package uses external assets (images/sounds) hosted on the web; for fully offline use, replace them with local files in the assets folder.

